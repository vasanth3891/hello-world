#library(Basic,lib.loc="S://Tianyin//Library//R")
library(fBasics)

as.numeric=function(x){
	y=as.double(x)
	names(y)=names(x)
	return(y)
}

Bollinger.Band=function(ts,days,band)
{
	if(!is.vector(ts)) stop("Needs a vector of price series")
	if(any(is.na(ts))){
		warning("Removing NA prices from the time series")
		ts=ts[!is.na(ts)]
	}
	if(length(ts)<=days) stop("Insufficient data points")
	data=cbind(Price=ts,Mean=rep(NA,length(ts)),Upper=rep(NA,length(ts)),Lower=rep(NA,length(ts)))
	data[,"Price"]=ts
	rownames(data)=names(ts)
	data[-(1:days),"Mean"]=sapply((days+1):length(ts),function(i) mean(ts[((i-days):(i-1))],na.rm=TRUE))
	data[-(1:days),"Upper"]=band*sapply((days+1):length(ts),function(i) sd(ts[((i-days):(i-1))],na.rm=TRUE))
	data[-(1:days),"Lower"]=(-1)*data[-(1:days),"Upper"]
	data[-(1:days),"Upper"]=data[-(1:days),"Upper"]+data[-(1:days),"Upper"]+data[-(1:days),"Mean"]
	data[-(1:days),"Lower"]=data[-(1:days),"Lower"]+data[-(1:days),"Lower"]+data[-(1:days),"Mean"]
	return(data[-(1:days),,drop=F])
}


CapWords=function(s,strict=FALSE){
	cap=function(s) paste(toupper(substring(s,1,1)),{
		s=substring(s,2)
		if(strict) 
			tolower(s) 
		else s
	},sep="",collapse=" ")
	sapply(strsplit(s,split=" "),cap,USE.NAMES=!is.null(names(s)))
}


cnames=function(x){
	dimnames(x)[[2]]
}

rnames=function(x){
	dimnames(x)[[1]]
}


ConvertSerialDate=function(serialdate){
	l=serialdate+68569+2415019
	n=(4*l)%/%146097
	l=l-((n*146097+3)%/%4)
	i=(4000*(l+1))%/%1461001
	l=l-((1461*i)%/%4)+31
	j=((80*l)%/%2447)
	day=l-((2447*j)%/%80)
	l=(j%/%11)
	month=j+2-(12*l)
	year=100*(n-49)+i+l
	date=paste(year,ifelse(nchar(month)==1,"0",""),month,ifelse(nchar(day)==1,"0",""),day,sep="")
	return(date)
}


EWMA=function(ts,n=0,lambda=0.94){
	if(n==0){
		n=length(ts)
	}
	W=((n-1):0)
	W=lambda^W
	ema=sapply(n:length(ts),function(i){
		return((ts[(i-n+1):i]%*%W)/sum(W))
	})
	names(ema)=names(ts)[n:length(ts)]
	return(ema)
}


lapsed.time=function(from,units="secs",digits=4){
	return(list(lapsed=paste(as.double(difftime(Sys.time(),
		from,units=units)),units),snap=Sys.time()))

}

list2matrix=function(input){

	columns=length(input)
	rows=0
	for (i in 1:columns){
		rows=max(rows,length(input[[i]]))
	}
	output=sapply(1:columns,function(j){
		retVal=input[[j]]
		if(length(retVal)<rows){
			retVal=c(retVal,rep(NA,rows-length(retVal)))
		}
		return(retVal)
	})
	output=data.frame(I(output))
	dimnames(output)[[2]]=names(input)
	return(output)
}


MonthEnd=function(month){
	year=substring(month,1,4)
	month=substring(month,5,6)
	date=ifelse(month=="02",ifelse(as.numeric(year)%%4,28,29),ifelse(month %in% c("04","06","09","11"),30,31))
	retVal=paste(month,date,year,sep="/")
	return(retVal)
}


MonthsAgo=function(date,ago,weekdays=NA){
	period=Period("190001","209912")
	prior.month=period[which(period==substring(date,1,6))-ago]
	if(is.na(weekdays[1])){
		retVal=yyyymmdd(MonthEnd(prior.month),"mm/dd/yyyy")
	}else{
		retVal=max(weekdays[substring(weekdays,1,6)==prior.month])
	}
	return(retVal)
}





Percentile=function(z,tile=0.5){
	y=Percentile.Rank(z)
	return(max(z[y<=tile & !is.na(y)]))
}

Percentile.Rank=function(z,method="EXCEL",returns=NA){
	Rank=switch(method,EXCEL=Rank.Excel,RANDOM=Rank.Random,RETADJ=Rank.ReturnsAdj,DEFAULT=Rank.Default)
	x<-as.numeric(z)
	y<-Rank(x,returns=returns,na.last=TRUE)
	if(method=="RETADJ"){
		returns=y[,"Returns"]
		y=y[,"Rank"]
	}
	nan<-sum(!is.na(x))
	y<-(y-1)/(nan-1)
	y[is.na(x)]<-NA
	names(y)=names(z)
	if(method=="RETADJ"){
		y=cbind(Ranks=y,Returns=returns)
	}
	return(y)
}


Period=function(start.month,end.month,freq="M"){
	mons=c("01","02","03","04","05","06","07","08","09","10","11","12")
	start.year=as.numeric(substring(start.month,1,4))
	end.year=as.numeric(substring(end.month,1,4))
	tmp=NULL
	for (year in start.year:end.year){
		tmp=c(tmp,paste(year,mons,sep=""))
	}
	retVal=tmp[match(start.month,tmp):match(end.month,tmp)]
	n=switch(freq,"M"=1,"Q"=3,"S"=6,"Y"=12)
	restrict=sapply(1:((length(retVal)%/%n)+1),function(i,n){
		return((i-1)*n+1)
	},n=n)
	retVal=retVal[restrict]
	retVal=retVal[!is.na(retVal)]
	return(retVal)
}


Rank.Default=function(x,returns=NA,na.last=TRUE){
	return(rank(x,na.last))
}


Rank.Excel=function(x,returns=NA,na.last=TRUE){
	ranks=sort.list(sort.list(x,na.last=na.last))
	if(is.na(na.last)) x<-x[is.orderable(x)]
	for(i in unique(x[duplicated(x)])){
		which = (x==i & !is.na(x))
		ranks[which]=ranks[which][1]
	}
	return(ranks)
}


Rank.Random=function(x,returns=NA,na.last=TRUE){
	if(any(duplicated(x))){
		x[duplicated(x)]=x[duplicated(x)]+runif(length(x[duplicated(x)]),0,1/le+05)
	}
	return(rank(x,na.last=na.last))
}


Rank.ReturnsAdj=function(x,returns=NA,na.last=TRUE){
	duplicated.values=unique(x[duplicated(x)])
	duplicated.values=duplicated.values[!is.na(duplicated.values)]
	if(length(duplicated.values)){
		for(dup in duplicated.values){
			z=names(x[x==dup])
			for(s in order(z)){
				x[z[s]]=x[z[s]]+s/1e+06
			}
		}
	}
	ranks=Rank.Excel(x,na.last=na.last)
	names(ranks)=names(x)
	return(cbind(Rank=ranks,Returns=returns[names(ranks)]))
}


Rolling=function(ts,roll=260){
	curr=prod(1+ts[1:roll]/100)
	max=curr
	min=curr
	invisible(sapply((roll+1):length(ts),function(t){
		curr<<-curr*(1+ts[t]/100)/(1+ts[t-roll]/100)
		if(curr>max) max<<-curr
		if(curr<min) min<<-curr
		return()
	}))
	ret=c("max"=100*(max-1),"min"=100*(min-1))
	names(ret)=c("max","min")
	return(ret)
}

Rolling.Sum=function(ts,k){
	if(k<=0 || k>=length(ts)) stop("Value of k invalid")
	len=length(ts)-k+1
	nas=is.na(ts)
	ts[nas]=0
	cumsum.ts=c(0,cumsum(ts))
	cumsum.nas=c(0,cumsum(nas))
	ans=tail(cumsum.ts,len)-head(cumsum.ts,len)
	ans[tail(cumsum.nas,len)-head(cumsum.nas,len)>0]=NA
	return(ans)
}

winsorize=function(i,winsorize,cutoff=F,ends=c("H","T")){
	if(is.list(winsorize) & any(!is.na(winsorize))){
		if(!(is.null(winsorize$SD) || is.na(winsorize$SD))){
			ubound=mean(i,na.rm=T)+winsorize$SD*sd(i,na.rm=T)
			lbound=mean(i,na.rm=T)-winsorize$SD*sd(i,na.rm=T)
			if(cutoff){
				if("H" %in% ends) i[!is.na(i) & i>ubound]=NA
				if("T" %in% ends) i[!is.na(i) & i<ubound]=NA
			}else{
				if("H" %in% ends) i[!is.na(i) & i>ubound]=ubound
				if("T" %in% ends) i[!is.na(i) & i<ubound]=lbound
			}	
		}
		if(!(is.null(winsorize$MAD) || is.na(winsorize$MAD))){
			ubound=median(i,na.rm=T)+winsorize$MAD*median(abs(i-median(i,na.rm=T)),na.rm=T)
			lbound=median(i,na.rm=T)-winsorize$MAD*median(abs(i-median(i,na.rm=T)),na.rm=T)
			if(cutoff){
				if("H" %in% ends) i[!is.na(i) & i>ubound]=NA
				if("T" %in% ends) i[!is.na(i) & i<ubound]=NA
			}else{
				if("H" %in% ends) i[!is.na(i) & i>ubound]=ubound
				if("T" %in% ends) i[!is.na(i) & i<ubound]=lbound
			}
		}
		if(!(is.null(winsorize$PRANK) || is.na(winsorize$PRANK))){
			if(cutoff){
				if("H" %in% ends) i[!is.na(i) & Percentile.Rank(i)<winsorize$PRANK]=NA
				if("T" %in% ends) i[!is.na(i) & Percentile.Rank(i)>(1-winsorize$PRANK)]=NA
			}else{
				if("H" %in% ends) i[!is.na(i) & Percentile.Rank(i)<winsorize$PRANK]=min(i[!is.na(i) & Percentile.Rank(i)>=winsorize$PRANK],na.rm=T)
				if("T" %in% ends) i[!is.na(i) & Percentile.Rank(i)>(1-winsorize$PRANK)]=max(i[!is.na(i) & Percentile.Rank(i)<=(1-winsorize$PRANK)],na.rm=T)
			}
		}
	}
	return(i)
}


standardize=function(i,winsorize=NA){
	if(is.list(winsorize) & any(!is.na(winsorize)))
		i=winsorize(i,winsorize)
	i=(i-mean(i,na.rm=T))/sd(i,na.rm=T)
	return(i)
}

Signal4Bands=function(band,curr=c("status"=3,"signal"=0),stagger=1){
	#There are 5 status here: 1) <Lower 2) [Lower,lower) 3) [lower,upper] 4) (upper,Upper] 5) >Upper
	status=curr[1];signal=curr[2]
	stat=ifelse(band["Price"]>band["Upper"],5,ifelse(band["Price"]>band["upper"],4,ifelse(band["Price"]<band["Lower"],1,ifelse(band["Price"]<band["lower"],2,3))))
	names(stat)=NULL
	if(stat==1){
		sig=signal-(1/stagger)
	}else if(stat==2){
		sig=signal+(1/stagger)*ifelse(status==1,1,-1)
		if(status==1) stat=1
	}else if(stat==3){
		sig=signal+(1/stagger)*ifelse(status==1,1,ifelse(status==5,-1,0))
		if (status %in% c(1,5)) stat=status
	}else if(stat==4){
		sig=signal+(1/stagger)*ifelse(status==5,-1,1)
		if(status==5) stat=5 
	}else if(stat==5){
		sig=signal+(1/stagger)
	}
	sig=ifelse(sig<0,0,ifelse(sig>1,1,sig))
	names(sig)=NULL
	return(c("status"=stat,"signal"=sig))
}





unpaste=function(str,sep,fields=2){
	a=strsplit(str,sep)
	b=lapply(1:fields,function(i,a){
		return(sapply(a,function(j,i){
			return(unlist(j[i]))
		},i=i))
	},a=a)
	return(b)
}

yyyymmdd=function(date,in.format="yyyy-mm-dd",out.format="yyyymmdd"){
	date=unpaste(as.character(date)," ")[[1]]
	sep=ifelse(in.format=="yyyymmdd",NA,ifelse(any(grep("-",in.format)),"-","/"))
	date=unpaste(date,sep,fields=3)
	if(in.format=="yyyy/mm/dd" | in.format=="yyyy-mm-dd"){
		year=date[[1]]
		month=paste(ifelse(nchar(date[[2]])==1,"0",""),date[[2]],sep="")
		date=paste(ifelse(nchar(date[[3]])==1,"0",""),date[[3]],sep="")
	}

	if(in.format=="mm/dd/yyyy" | in.format=="mm-dd-yyyy"){
		year=date[[3]]
		month=paste(ifelse(nchar(date[[1]])==1,"0",""),date[[1]],sep="")
		date=paste(ifelse(nchar(date[[2]])==1,"0",""),date[[2]],sep="")
	}

	if(in.format=="yyyymmdd"){
		year=substring(date[[1]],1,4)
		month=substring(date[[1]],5,6)
		date=substring(date[[1]],7,8)
	}

	if(in.format=="dd/mm/yyyy" | in.format=="dd-mm-yyyy"){
		year=date[[3]]
		month=paste(ifelse(nchar(date[[2]])==1,"0",""),date[[1]],sep="")
		date=paste(ifelse(nchar(date[[1]])==1,"0",""),date[[2]],sep="")
	}

	retVal=switch(out.format,"yyyy-mm-dd"=paste(year,month,date,sep="-"),
							"yyyy/mm/dd"=paste(year,month,date,sep-"/"),
							"yyyymmdd"=paste(year,month,date,sep=""),
							"mm/dd/yyyy"=paste(month,date,year,sep="/"),
							"mm-dd-yyyy"=paste(month,date,year,sep="-"),
							"dd-mm-yyyy"=paste(date,month,year,sep="-"),
							"dd/mm/yyyy"=paste(date,month,year,sep="/"))
	return(retVal)
}





