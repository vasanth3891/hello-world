
FactorStandardAnalyics=function(){

#variables coming from Java
vars=NULL
vars$n=nap
vars$start.date=startDate
vars$end.date=endDate
vars$history=historyVec[1:9]
vars$prd=prdVec
names(vars$prd)=(-(5:10))
vars$cash="tbill"
vars$vol=c(NA,12)[1]
vars$upload=T
vars$spread=F
vars$equal=F
if(vars$spread || vars$equal) vars$upload=F
vars$bmk=benchmarkCode
vars$bmkId=benchmarkIdentity
vars$assets=indexIdentity
rownames(vars$assets)=NULL
vars$dates=indexAllDates
Data=tGrossReturnData
Data=tapply(Data[,"tot_return_gross_usd"],Data[,c("date","short_name")],sum)
Data=Data[,unique(vars$assets[,"short_name"])]
cashrate=cashrateData

#tmp=c(cashrate[-1,"date"],as.Date(vars$end.date))
tmp=c(cashrate[,"date"])
cashrate=cashrate[,"pclose"]
tmp<-format(as.Date(tmp), "%m/%Y")	
names(cashrate)=tmp
cashrate=100*((1+(cashrate+ifelse(length(grep("[0-9]",vars$cash)),as.numeric(gsub("[-+a-z]","",vars$cash)),0)/100)/100)^(1/vars$n)-1)

if(vars$spread && vars$equal==FALSE){
	#spread
	tmp=vars$assets[!(vars$assets[,"short_name"] %in% vars$bmk),"short_name"]
	Data[,tmp]=Data[,tmp]-Data[,vars$bmk[tmp]]
}else tmp=unique(colnames(Data))

ret1=do.call("rbind",lapply(vars$bmk,function(col1){

ret=do.call("rbind",lapply(tmp,function(col){
	
	cat("\n",col,":",sep="")
	data=Data[,col]
	
	id=vars$assets[vars$assets[,"short_name"]==col,"instrument_id"][1]
        id_name=vars$assets[vars$assets[,"short_name"]==col,"name"][1]
        id_key=vars$assets[vars$assets[,"short_name"]==col,"key"][1]
	
        bmk_name=vars$bmkId[vars$bmkId[,"code"]==col1,"name"][1]
        bmk_key=vars$bmkId[vars$bmkId[,"code"]==col1,"key"][1]

	if((col %in% vars$bmk)&&(col==col1)) vars$bmk=NA else vars$bmk=col1
	
    cat("bmk=",vars$bmk,",",sep="")
		if(length(id)==0) id=NA
		
	ret=do.call("rbind",lapply(vars$history,function(his){
	 	if(his>0){
			data=data[as.Date(names(data))>=as.Date(vars$dates[length(vars$dates)-his*vars$n+1])]
		}else if (his<0){
			end.date=vars$prd[as.character(his)]
			if(his==max(as.numeric(names(vars$prd)))) start.date=vars$start.date else start.date=vars$prd[as.character(his+1)]
			data=data[as.Date(names(data))>as.Date(start.date) & as.Date(names(data))<=as.Date(end.date)]
		}

		if((his==0 & sum(is.na(data))==0) | (!is.na(his) & sum(!is.na(data))>=vars$n*his-1)){
			data=data[!is.na(data)]
			ret=do.call("rbind",lapply(c(0,1),function(net){
				data=data-cashrate[format(as.Date(names(data)), "%m/%Y")]*net
				    ret=do.call("rbind",lapply(vars$vol,function(vol){
					if(!is.na(vol)) data=data/sd(data)/sqrt(vars$n)*vol
					
					if(!is.na(vars$bmk)){					
						sum=Annualized.Summary(data,cashrate=(1-net)*cashrate[format(as.Date(names(data)), "%m/%Y")],market=Data[names(data),vars$bmk],n=vars$n)                    		
					}else{
						sum=Annualized.Summary(data,cashrate=(1-net)*cashrate[format(as.Date(names(data)), "%m/%Y")],market=NA,n=vars$n)
					}
					sum=sum[!is.na(sum) & !is.infinite(sum)]					
					Upload=data.frame("instrument_id"=id,"instrument_name"=id_name,"instrument_key"=id_key,"net"=net,"freq"=ifelse(vars$n==12,'M','D'),"leverage"=vol,"market"=vars$bmk,"market_name"=bmk_name,"market_key"=bmk_key,"history"=his,"start_date"=names(data)[1],"end_date"=names(data)[length(data)],"summary_name"=names(sum),"data"=as.character(sum),stringsAsFactors=F,row.names=NULL,check.names=F)
					#write.table(Upload, "/local/apps/idsuser/r-process/r-daemon/output/StatOutput.csv", sep=",", col.names= T, row.names = F, append = T)					
					return(Upload)
				}))
				return(ret)
			}))
		}else ret=NULL
		return(ret)
	}))
	return(ret)
}
))

return(ret)

}))

return(ret1)

}
