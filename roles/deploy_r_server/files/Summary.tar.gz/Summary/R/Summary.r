library(fBasics)
#library(Basic,lib.loc="C:/R-3.3.2/library")
library(Basic)

Annualized.Summary=function(returns,market=NA,cashrate=NA,styles=NULL,countries=NULL,sectors=NULL,n=12,market2=NULL,mode=0,db.output=FALSE,stepwise=TRUE,pure.excess=TRUE)
{
	#market=NA;cashrate=NA;styles=NULL;countries=NULL;sectors=NULL;n=12;market2=NULL;mode=0;db.output=FALSE;stepwise=TRUE;pure.excess=TRUE
	if(substr(names(returns)[1],5,5)=="-") names(returns)=yyyymmdd(names(returns))
	wealth.pnl=Wealth.Curve(returns,prices=FALSE)
	summary=sapply(unique(substr(names(returns),1,4)),function(year){
		wealth.year=which(substr(names(wealth.pnl),1,4)==year)
		return((wealth.pnl[wealth.year[length(wealth.year)]]/wealth.pnl[wealth.year[1]-1]-1)*100)
	})
	names(summary)=unique(substr(names(returns),1,4))

	summary.others=((wealth.pnl[length(wealth.pnl)]/wealth.pnl[1])^(n/(length(wealth.pnl)-1))-1)*100
	summary.others=c(summary.others,sd(returns)*sqrt(n),skewness(returns)/sqrt(n),(kurtosis(returns)-3)/n)
	summary.others=c(summary.others,summary.others[1]/summary.others[2])
	names(summary.others)=c("Annualised returns","Annualised volatility","Annualised skewness","Annualised excess kurtosis","Risk Adj Return")

	summary.others=c(summary.others,sapply(1:5,function(yy){
		if(length(wealth.pnl)>yy*n){
			wealth.pnl=wealth.pnl[(length(wealth.pnl)-yy*n):length(wealth.pnl)]
			summary.others=((wealth.pnl[length(wealth.pnl)]/wealth.pnl[1])^(n/(length(wealth.pnl)-1))-1)*100
		}else summary.others=NA
		return(summary.others)
	}))
	names(summary.others)[(length(summary.others)-5+1):length(summary.others)]=c("Annualised returns, last 1 year",paste("Annualised returns, last ",2:5," years",sep=""))
	
	#Fit a line
	summary.others=c(summary.others,Fitted(returns,n=n))

	#Omega
	summary.others=c(summary.others,'Omega at 0%'=Omega.Ratio(returns,cut=0))
	names.others=names(summary.others)

	if(!is.na(cashrate[1])){
		summary.others=c(summary.others,'Omega at cashrate'=Omega.Ratio(returns,cut=cashrate))		
		names.others=names(summary.others)
	}

	if(!is.na(market[1])){
		summary.others=c(summary.others,'Omega (market relative)'=Omega.Ratio(returns,cut=market))		
		names.others=names(summary.others)
	}


	if(!is.na(cashrate[1])){
		cashrate.pnl=Wealth.Curve(cashrate,prices=FALSE)
		cashrate.returns=((cashrate.pnl[length(cashrate.pnl)]/cashrate.pnl[1])^(n/(length(cashrate.pnl)-1))-1)*100
		summary.others=c(summary.others,(summary.others["Annualised returns"]-cashrate.returns)/summary.others["Annualised volatility"],
							RiskAdjustedReturn(returns,cashrate,type="Sortino",freq=ifelse(n==12,"M",ifelse(n==52,"W","D"))),
							RiskAdjustedReturn(returns,cashrate,type="IR",freq=ifelse(n==12,"M",ifelse(n==52,"W","D"))))
		names(summary.others)[(length(summary.others)-2):length(summary.others)]=c("Sharpe ratio","Sortino ratio","Information Ratio")	
	}

	trade.summary=c("No. of Winning Trades"=length(returns[returns>0]),
					"No. of Trades"=length(returns[returns!=0]),
					"Avg Winning Trades Return (%)"=mean(returns[returns>0],na.rm=TRUE),
					"Avg Losing Trades Return (%)"=mean(returns[returns<0],na.rm=TRUE))
	summary.others=c(summary.others,"Kelly criterion"=Kelly.Criterion(trade.summary))

	summary.others=c(summary.others,do.call("c",lapply(n*(1:3),RollingMinMax,ts=returns,unit=ifelse(n==260,"day","month"))))

	if(mode==1){
		last5yrs=sort(unique(substr(names(returns),1,4)),decreasing=TRUE)[1:6]
		wealth.pnl.5yrs=Wealth.Curve(returns[substr(names(returns),1,4) %in% last5yrs],prices=FALSE)
		summary.others=c(summary.others,((wealth.pnl.5yrs[length(wealth.pnl.5yrs)]/wealth.pnl.5yrs[1])^(n/(length(wealth.pnl.5yrs)-1))-1)*100)
		names(summary.others)[length(summary.others)]="Annualised returns over the last 5 years"
	}

	if(!is.na(market[1])){
		returns=cbind(market,returns)
		summary.others=c(summary.others,"Average monthly return in up market"=mean(returns[returns[,1]>=0,2],na.rm=TRUE),
										"Average monthly return in down market"=mean(returns[returns[,1]<0,2],na.rm=TRUE))
		summary.others=c(summary.others,summary.others["Average monthly return in up market"]/summary.others["Average monthly return in down market"])
		names(summary.others)[length(summary.others)]="Returns in up market/Returns in down market"
	}

	if(!is.na(cashrate[1]) & !is.na(market[1])){
		returns.excess=returns-cashrate
		summary.others=c(summary.others,"Average monthly excess returns in up market"=mean(returns.excess[returns.excess[,1]>=0,2],na.rm=TRUE),
										"Average monthly excess returns in down market"=mean(returns.excess[returns.excess[,1]<0,2],na.rm=TRUE))
		summary.others=c(summary.others,
							summary.others["Average monthly excess returns in up market"]/summary.others["Average monthly excess returns in down market"])
		names(summary.others)[length(summary.others)]="Excess returns in up market/Excess returns in down market"
	}

	if(!is.na(market[1])){
		summary.others=c(summary.others,"Percentage of months with + returns"=nrow(returns[returns[,2]>=0,,drop=FALSE])/nrow(returns)*100,
										"Best monthly return"=max(returns[,2]),'Worst monthly return'=min(returns[,2]))
		names.others=names(summary.others)
		summary.others=c(summary.others,summary(lm(returns[,2]~returns[,1]))$coeff[1,c(1,3)],
										summary(lm(returns[,2]~returns[,1]))$coeff[2,1],
										ifelse(rep(sum(returns[,1]>=0,na.rm=T)>1,3),
											c(summary(lm(returns[returns[,1]>=0,2]~returns[returns[,1]>=0,1]))$coeff[1,c(1,3)],
											summary(lm(returns[returns[,1]>=0,2]~returns[returns[,1]>=0,1]))$coeff[2,1]),rep(NA,3)),
										ifelse(rep(sum(returns[,1]<0,na.rm=T)>1,3),
											c(c(summary(lm(returns[returns[,1]<0,2]~returns[returns[,1]<0,1]))$coeff[1,c(1,3)]),
											summary(lm(returns[returns[,1]<0,2]~returns[returns[,1]<0,1]))$coeff[2,1]),rep(NA,3)),
										cor(returns)[1,2],TrackingError(returns[,1], returns[,2], scale = NA),
										UpDownRatios(returns[,2], returns[,1], side = "Up", method = "Capture"),
										UpDownRatios(returns[,2], returns[,1], side = "Down", method = "Capture"))
		names(summary.others)=c(names.others,"Alpha (market relative)","T-stats of alpha",
											"Beta to market",
											"Up market alpha","T-stats of up market alpha",
											"Beta in up market",
											"Down market alpha","T-stats of down market alpha",
											"Beta in down market",
											"Correlation with market","Tracking Error","Up Capture","Down Capture")
	}else{
		summary.others=c(summary.others,"Percentage of months with + returns"=length(returns[returns>=0,drop=FALSE])/length(returns)*100,
										"Best monthly return"=max(returns),"Worst monthly return"=min(returns))
	}
	
	if(!is.null(styles) && (is.matrix(styles) | is.data.frame(styles))){
		if(is.null(market2)) market2=market
		if(mode==1){
			summary.styles=c(summary(lm(returns[,2]~styles[,1]))$coeff[2,1],c(summary(lm(returns[,2]~cbind(market2,styles[,1])))$coeff[1:3,c(1,3)]))
			names(summary.styles)=c("Beta to LargeCap-SmallCap Index","Alpha (2 factor)","Beta to Market (2 factor)",
									"Beta to Size (2 factor)","Alpha T-stats (2 factor)","Beta to Market T-stats (2 factor)",
									"Beta to Size T-stats (2 factor)")
		}else{
			summary.styles=c(summary(lm(returns[,1]~styles[,1]))$coeff[2,1],summary(lm(returns[,2]~styles[,2]))$coeff[2,1],
							c(summary(lm(returns[,2]~cbind(market2,styles[,2])))$coeff[1:3,c(1,3)]),
							summary(lm(returns[,2]~cbind(market2,styles[,1],styles[,2])))$coeff[1,c(1,3)])
			names(summary.styles)=c("Beta against GV index","Beta agaist LargeCap-SmallCap Index","Alpha (2 factor)","Beta to Market (2 factor)",
									"Beta to Size (2 factor)","Alpha T-stats (2 factor)","Beta to Market T-stats (2 factor)",
									"Beta to Size T-stats (2 factor)","Alpha (3 factor)","T-stats (3 factor)")
		}
		summary.others=c(summary.others,summary.styles)
	}
		
	if(!is.null(countries) && (is.matrix(countries) | is.data.frame(countries))){
		X=countries
		if(!is.null(sectors) && (is.matrix(sectors) | is.data.frame(sectors))){
			sectors=sectors[names(market),]
			X=cbind(X,sectors)
			colnames(X)[(ncol(X)-ncol(sectors)+1):ncol(X)]=colnames(sectors)
		}

		if(is.matrix(styles) | is.data.frame(styles)){
			X=cbind(X,styles[names(market),1])
			colnames(X)[ncol(X)]="Size"
		}

		if(pure.excess & !is.null(market2)){
			regress.data=cbind(Returns=returns[,2]-market2,X)
		}else{
			regress.data=cbind(Returns=returns[,2],X)		
		}
		
		if(stepwise){
			equation=paste("regress.data[,'",colnames(regress.data)[1],"']~",paste("regress.data[,",
				colnames(regress.data)[-1],"]",sep="'",collapse="+"),sep="")
			explain=lm(formula=as.formula(equation),data=as.data.frame(regress.data,stringsAsFactor=F,check.names=F))
			palpha=step(explain,trace=FALSE)
			beta.summary=summary(palpha)$coeff[,1]
			beta.summary[1]=100*(((1+beta.summary[1]/100)^12)-1)
				
			if(length(beta.summary)>1){					
				names(beta.summary)=c("Pure Alpha",paste("Beta to",CapWords(sapply(rownames(summary(palpha)$coeff)[-1],function(i)
					substring(i,17,nchar(i)-2)),strict=TRUE)))
			}else{
				names(beta.summary)="Pure Alpha"
			}
			tstats.summary=summary(palpha)$coeff[,3]
				
			if(length(tstats.summary)>1){
				names(tstats.summary)=c("T-stats of pure alpha",paste("TStats of",CapWords(sapply(rownames(summary(palpha)$coeff)[-1],function(i)
					substring(i,17,nchar(i)-2)),strict=TRUE)))
			}else{
				names(tstats.summary)="T-stats of pure alpha"
			}
			summary.palpha=c(beta.summary,tstats.summary,"RSquared of pure alpha"=summary(palpha)$r.sq)
		}else{
			palpha=lm(returns[,2]~X)
			summary.palpha=c(summary(palpha)$coeff[,1],summary(palpha)$coeff[,3],summary(palpha)$r.squared)
			names(summary.palpha)=c("Pure Alpha",paste("Beta to",CapWards(colnames(X),strict=TRUE)),"T-stats of pure alpha",
								paste("TStats of",CapNords(colnames(X),strict=TRUE)),"Rsquared of pure alpha")
		}
		summary.others=c(summary.others,summary.palpha)
	}

	#Draw-down
	if(is.na(market[1])){
		market=NULL
	}else{
		if(any(grep("[0-9]{4}-[0-9]{2}-[0-9]{2}",names(market)))){
			names(market)=yyyymmdd(names(market),"yyyy-mm-dd","yyyymmdd")
		}
		market=Wealth.Curve(market)
	}
	drawdown.stats=DrawDowns(wealth.pnl,market)
	if(nrow(drawdown.stats)){
		summary.drawdown=NULL
		for(i in 1:min(3,nrow(drawdown.stats))){
			tmp.summary=drawdown.stats[i,]
			names(tmp.summary)=paste("[",i,"]",names(tmp.summary),sep="")
			if(is.null(summary.drawdown)){
				summary.drawdown=tmp.summary
			}else{
				summary.drawdown=c(summary.drawdown,tmp.summary)
			}
		}
		summary.drawdown=c(ifelse(summary.others[1]>0,abs(summary.others[1]/as.numeric(drawdown.stats[1,"Draw-down"])),NA),
				ifelse(summary.others[1]>0,abs(summary.others[1]/as.numeric(mean(drawdown.stats[1:min(3,nrow(drawdown.stats)),"Draw-down"],na.rm=TRUE))),NA),
				nrow(drawdown.stats[drawdown.stats[,"Draw-down"]<=(-5),,drop=F]),summary.drawdown)
		names(summary.drawdown)[1:3]=c("Return to max draw-down","Return to worst 3 draw-downs","No of 5% draw-downs")
		summary=c(summary,summary.others,summary.drawdown)
	}else{
		summary=c(summary,summary.others)
	}
	return(summary)
}


Compound.Returns=function(ret,mode="M",price=FALSE)
{
	#dbconn=odbcConnect("PROD","root","root")
	if(price){
		ret=(ret[-1]/ret[-length(ret)]-1)*100
	}
	if(mode=="Y"){
		tt.dates=paste(substr(gsub("-","",names(ret)),1,4),"12",sep="")
	}else if(mode=="S"){
		months=substr(gsub("-","",names(ret)),5,6)
		tt.dates=paste(substr(gsub("-","",names(ret)),1,4),ifelse(months %in% paste("0",1:6,sep=""),"06","12"),sep="")
	}else if(mode=="Q"){
		months=substr(gaub("-","",names(ret)),5,6)
		tt.dates=paste(substr(gsub("-","",names(ret)),1,4),ifelse(months %in% paste("0",1:3,sep=""),"03",
					ifelse(months %in% paste("0",4:6,sep=""),"06",ifelse(months %in% paste("0",7:9,sep=""),"09","12"))),sep="")
	}else{
		tt.dates=substr(gsub("-","",names(ret)),1,6)
	}
	all.dates=sort(unique(tt.dates),decreasing=FALSE)
	
	#all.dates=cbind(all.dates,sapply(all.dates,function(x){
	#	return(DBDate(x,"DT"))
	#}))
	
	#ldm=format(sqlQuery.mod(dbconn,paste("select DATE,dbo.fn_getmonthend(DATE,0) As LDM FROM DATES where date in ('",paste(all.dates[,2],collapse="','",sep=""),"')",sep=""),stringsAsFactors=FALSE,rownames=1),"%Y-%m-%d")
	#all.dates[,2]=ldm[all.dates[,2],"LDM"]
	
	
	#as.character(sqlQuery(dbconn,paste("select date from dates where date between '",yyyymmdd(paste(all.dates[1],"01",sep=""),in.format="yyyymmdd",out.format="yyyy-mm-dd"),"' and '",yyyymmdd(paste(all.dates[length(all.dates)],"31",sep=""),in.format="yyyymmdd",out.format="yyyy-mm-dd"),"'"))[,1])
	#all.dates=cbind(all.dates,)
	
	#all.dates=cbind(all.dates,c(paste(substr(LDM,1,4),substr(LDM,6,7),substr(LDM,9,10),sep=""),"20130329"))

	tt.ret=sapply(all.dates[,1],function(d){
		ret=ret[tt.dates %in% d]
		ret=ret[!is.na(ret)]
		if(length(ret)==0) return(NA)
		c.ret=cumprod(1+ret/100)
		c.ret=(c.ret[length(c.ret)]-1)*100
		return(c.ret)
	})
	names(tt.ret)=all.dates[,2]
	#odbcClose(dbconn)
	return(tt.ret)
}



DrawDowns=function(ts,mkt=NULL){
	current.peak.index=1
	drawdown.stats=NULL
	i=2
	while(i<=length(ts)){
		if(ts[i]>=ts[i-1]){
			current.peak.index=i
		}else{
			start.date=names(ts)[current.peak.index]
			tt.ts=ts[i:length(ts)]
			tt.ts=tt.ts[tt.ts>=ts[current.peak.index]]
			if(length(tt.ts)){
				end.date=names(tt.ts)[1]
			}else{
				end.date=names(ts)[length(ts)]
			}
			trough.period=ts[current.peak.index:match(end.date,names(ts))]
			trough.date=names(trough.period[order(trough.period,decreasing=F)])[1]
			length.drawdown=match(trough.date,names(ts))-current.peak.index
			drawdown.size=(ts[trough.date]/ts[start.date]-1)*100
			highwater.level=ts[start.date]
			length.recovery=match(end.date,names(ts))-match(trough.date,names(ts))
			total.period=match(end.date,names(ts))-match(start.date,names(ts))

			if(is.null(mkt)){
				drawdown.stats=rbind(drawdown.stats,cbind(start.date,trough.date,end.date,length.drawdown,drawdown.size,length.recovery,total.period))		
			}else{
				mkt.size=(mkt[trough.date]/mkt[start.date]-1)*100
				drawdown.stats=rbind(drawdown.stats,cbind(start.date,trough.date,end.date,length.drawdown,drawdown.size,length.recovery,total.period,mkt.size))
			}
			i=current.peak.index=match(end.date,names(ts))
		}
		i=i+1
		#cat(i,"\n")
	}

	if(is.null(drawdown.stats)){
		if(is.null(mkt)){
			drawdown.stats=matrix(NA,nrow=0,ncol=7,dimnames=list(NULL,c("Start Date","Trough Date","End Date","Length","Draw-down","Recovery Length","Total Length")))
		}else{
			drawdown.stats=matrix(NA,nrow=0,ncol=8,dimnames=list(NULL,c("Start Date","Trough Date","End Date","Length","Draw-down","Recovery Length","Total Length","Market Returns")))
		}	
	}else{
		if(is.null(mkt)){
			dimnames(drawdown.stats)=list(NULL,c("Start Date","Trough Date","End Date","Length","Draw-down","Recovery Length","Total Length"))
		}else{
			dimnames(drawdown.stats)=list(NULL,c("Start Date","Trough Date","End Date","Length","Draw-down","Recovery Length","Total Length","Market returns"))
		}
		mode(drawdown.stats)="numeric"	
	}
	if(is.vector(drawdown.stats)){
		drawdown.stats=t(as.matrix(drawdown.stats))
	}
	if(nrow(drawdown.stats)){
		#drawdown.stats=drawdown.stats[order(as.numeric(drawdown.stats[,"Draw-down"])),,drop=F]
		drawdown.stats=drawdown.stats[order(drawdown.stats[,"Draw-down"]),,drop=F]
		drawdown.stats[rowSums(drawdown.stats[,c("Trough Date","End Date"),drop=F]==names(ts)[length(ts)])>=1,c("End Date","Recovery Length")]=NA	
	}
	return(drawdown.stats)
}






Kelly.Criterion=function(trade.summary){
	w=trade.summary["No. of Winning Trades"]/trade.summary["No. of Trades"]
	r=abs(trade.summary["Avg Winning Trades Return (%)"]/trade.summary["Avg Losing Trades Return (%)"])
	k=ifelse(r!=0,w-((1-w)/r),NA)*100
	names(k)=NULL
	return(k)
}


Wealth.Curve=function(ts,prices=FALSE,na.rm=FALSE){

	if(prices){
		op=cbind(prices=ts[-1],returns.cumul=ts[-1]/ts[-length(ts)])
		dimnamcs(op)[[1]]=names(ts)[-1]
	}else{
		op=cbind(returns=ts,returns.cumul=(1+ts/100))
		dimnames(op)[[1]]=names(ts)
	}

	if(na.rm){
		op=op[!is.na(op[,"returns.cumul"]),]
	}else{
		op[is.na(op[,"returns.cumul"]),"returns.cumul"]=0
	}
	wealth.curve=cumprod(op[,"returns.cumul"])
	wealth.curve=c(1,wealth.curve)
	names(wealth.curve)=c("start",dimnames(op)[[1]])
	return(wealth.curve)
}



RiskAdjustedReturn=function(returns,benchmark=NULL,type=c("IR","Sharpe","Sortino"),freq=c("M","Y","D"))
{
	rar=NA
	n=ifelse(freq=="M",12,ifelse(freq=="W",52,260))
	if(type=="IR"){
		wealth.pnl=Wealth.Curve(returns,prices=FALSE)
		rets=((wealth.pnl[length(wealth.pnl)]/wealth.pnl[1])^(n/(length(wealth.pnl)-1))-1)*100
		volatility=sd(returns)*sqrt(n)
		rar=rets/volatility
	}
	if(type=="Sharpe"){
		if(is.null(benchmark)){
			stop("Benchmark required to compute Sharpe")
		}
		#excess.pnl=Wealth.Curve(returns-benchmark,prices=FALSE)
		#rets=((excess.pnl[length(excess.pnl)]/excess.pnl[1])^(n/(length(excess.pnl)-1))-1)*100
		#volatility=sd((returns-benchmark))*sqrt(n)
		#rar=rets/volatility
		excess.pnl1=Wealth.Curve(returns,prices=FALSE)
		rets1=((excess.pnl1[length(excess.pnl1)]/excess.pnl1[1])^(n/(length(excess.pnl1)-1))-1)*100
		excess.pnl2=Wealth.Curve(benchmark,prices=FALSE)
		rets2=((excess.pnl2[length(excess.pnl2)]/excess.pnl2[1])^(n/(length(excess.pnl2)-1))-1)*100
		rets=rets1-rets2
		volatility=sd((returns))*sqrt(n)
		rar=rets/volatility
	}
	if(type=="Sortino"){
		if(is.null(benchmark)){
			stop("Benchmark required to compute Sortino")
		}
		excess.returns=returns-benchmark
		#excess.pnl=Wealth.Curve(excess.returns,prices=FALSE)
		#rets=((excess.pnl[length(excess.pnl)]/excess.pnl[1])^(n/(length(excess.pnl)-1))-1)*100
		
		excess.pnl1=Wealth.Curve(returns,prices=FALSE)
		rets1=((excess.pnl1[length(excess.pnl1)]/excess.pnl1[1])^(n/(length(excess.pnl1)-1))-1)*100
		excess.pnl2=Wealth.Curve(benchmark,prices=FALSE)
		rets2=((excess.pnl2[length(excess.pnl2)]/excess.pnl2[1])^(n/(length(excess.pnl2)-1))-1)*100
		rets=rets1-rets2

		excess.returns[excess.returns>0]=0
		#volatility=sd((excess.returns))*sqrt(n)
		volatility=sqrt(sum(excess.returns^2)/length(excess.returns))*sqrt(n)
		rar=rets/volatility
	}
	return(rar)
}




Omega.Ratio=function(ts,cut=0){
	omega=NA
	if(is.vector(ts) & length(ts)>=2){
		if(is.vector(cut)){
			if(length(cut)==1) cut=rep(cut,length(ts))
			po=sum(ifelse(ts>cut,ts-cut,0))
			ne=sum(ifelse(ts<cut,cut-ts,0))
			if(is.na(po) | is.na(ne)){
			 return(omega)} else{
			if(po>0.01 & ne>0.01) {omega=po/ne}}
		}
	}
	return(omega)
}


RollingMinMax=function(ts,n,unit="month"){
	min=NA;max=NA
	
	if(is.vector(ts) & length(ts)>=n){	
		min=prod(1+ts[1:n]/100);max=min
		
		if(length(ts)>n){
			invisible(sapply((n+1):length(ts),function(dt){
				ret=prod(1+ts[(dt-n+1):dt]/100)
				min<<-min(min,ret)
				max<<-max(max,ret)
				return()
			}))
		}
	}
	ret=c("Minimum"=100*(min-1),"Maximun"=100*(max-1))
	names(ret)=paste(names(ret)," rolling ",n,"-",unit,"s returns",sep="")
	return(ret)
}


Fitted=function(ts,n=12,model="loglinear"){
	ret=c("Annualised growth of trend"=NA,"Maximum DD w.r.t trend"=NA,"Annualised volatility of de-trended series"=NA,"Information ratio w.r.t trend"=NA)
	if(is.vector(ts) & sum(!is.na(ts))>=6){
		ts=ts[!is.na(ts)]
		ts=data.frame(x=(0:length(ts)),"ts"=c(NA,ts),"nav"=Wealth.Curve(ts),check.names=F)
		ts=data.frame(ts,"log"=log(ts[,"nav"]),check.names=F)
		
		if(model=="loglinear"){
			r.out=lm(log~x,ts,na.action=na.omit)	
			ts=cbind(ts,"fitted"=exp(r.out$coeff[1]+ts[,"x"]*r.out$coeff[2]))
			ts=cbind(ts,"error"=100*(ts[,"nav"]/ts[,"fitted"]-1))
			ret["Annualised growth of trend"]=100*((1+r.out$coeff[2])^n-1)
			ret["Maximum DD w.r.t trend"]=min(ts[,"error"])
			ret["Annualised volatility of de-trended series"]=sd(ts[,"error"])*sqrt(n)
			ret["Information ratio w.r.t trend"]=ret["Annualised growth of trend"]/ret["Annualised volatility of de-trended series"]
		}
		#if(model==??){}
	}
	return(ret)
}

